let nome = "Super man"
let idade = 100
let poder = "Super força"

nome = "Batman"
poder = "Rico"
console.log(
    `Nome: ${nome}
    Idade ${idade}
    Poder: ${poder}`
)
 
