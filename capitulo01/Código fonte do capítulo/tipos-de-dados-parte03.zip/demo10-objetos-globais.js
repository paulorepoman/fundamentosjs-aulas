console.log( 'keys', Object.keys({ nome: 'Erick'}))
console.log( 'values', Object.values({ nome: 'Erick'}))
console.log('now', Date.now())
console.log('random', Math.random())

// global
console.log('global', global)